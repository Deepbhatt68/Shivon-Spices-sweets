from django.contrib import admin
from shivonapp.models import *

admin.site.register(Admin)
admin.site.register(Area)
admin.site.register(City)
admin.site.register(Customer)
admin.site.register(Employee)
admin.site.register(Category)
admin.site.register(State)
admin.site.register(Unit)
admin.site.register(Product)
admin.site.register(ProductPacking)
admin.site.register(ProductSubcategory)
admin.site.register(Production)
admin.site.register(ProductionProduct)
admin.site.register(ProductionRm)
admin.site.register(ProductionStock)
admin.site.register(Purchase)
admin.site.register(PurchaseDesc)
admin.site.register(RawMaterial)
admin.site.register(RmStock)
admin.site.register(Sell)
admin.site.register(SellDetail)
admin.site.register(Supplier)



# Register your models here.
