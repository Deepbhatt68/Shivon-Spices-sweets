from django.shortcuts import render,redirect
from shivonapp.models import *
from django.core.files.storage import FileSystemStorage 
from datetime import date
from django.contrib.sessions.models import Session
from django.contrib import messages
from django.utils.datastructures import MultiValueDictKeyError


# Create your views here.
#admin
def adminlist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")

    admins =Admin.objects.all()
    return render(request,"adminlist.html",{'admins':admins})

def adashboard(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    ocnt=Sell.objects.all().count()
    cus=Customer.objects.all().count()
    prd=Product.objects.all().count()
    employee=Employee.objects.all().count()

    return render(request,"dashboard.html",{"ocnt":ocnt,"cus":cus,"prd":prd,"employee":employee})

def logout(request):
    Session.objects.all().delete()
    return redirect("/home/")

def adminadd(request):
     if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
     return render(request,"adminadd.html")

def adminsave(request):
    id =request.POST.get('a_id')
    name =request.POST.get('a_name')
    password =request.POST.get('a_password')
    Admin.objects.create(a_id=id, a_name = name,a_password = password)
    return redirect("/adminlist/")

def admindel(request,id):
    a = Admin.objects.get(a_id = id)
    a.delete()
    return redirect("/adminlist/")

def adminedit(request,id):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    admin =Admin.objects.get(a_id=id)
    return render(request,"adminedit.html",{'admin':admin})

def adminupdate(request,id):
    admin=Admin.objects.get(a_id=id)
    name =request.POST.get('a_name')
    password =request.POST.get('a_password')
    
    admin.a_name = name
    admin.a_password = password
    admin.save()
    return redirect("/adminlist/")

    #category

def clist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    categorys=Category.objects.all()
    return render(request,"clist.html",{'categorys':categorys})
def cdel(request,id):
    c=Category.objects.get(cid=id)
    c.delete()
    return redirect("/clist/")

def cedit(request,id):
    c=Category.objects.get(cid=id)
    return render(request,"cedit.html",{'category':c})
    
# def cupdate(request,id):
#     c=Category.objects.get(cid=id)
#     name= request.POST.get('cname')
#     cfile=request.FILES["cimg"]
#     fss=FileSystemStorage()
#     sfile=fss.save(cfile.name,cfile)
#     imgurl=fss.url(sfile)
#     c.cname=name
#     c.cimg= imgurl
#     c.save()
#     return redirect("/clist/")

def cupdate(request, id):
    c = Category.objects.get(cid=id)
    name = request.POST.get('cname')
    
    # Check if new image is provided
    if 'cimg' in request.FILES:
        cfile = request.FILES["cimg"]
        fss = FileSystemStorage()
        sfile = fss.save(cfile.name, cfile)
        imgurl = fss.url(sfile)
        c.cimg = imgurl
    
    c.cname = name
    c.save()
    return redirect("/clist/")
def cadd(request):
    return render(request,"cadd.html")

def csave(request):
    name=request.POST.get('cname')
    cfile=request.FILES["cimg"]
    fss=FileSystemStorage()
    sfile=fss.save(cfile.name,cfile)
    imgurl=fss.url(sfile)
    Category.objects.create(cname=name,cimg=imgurl)
    return redirect("/clist/")

def cattab(request):
    categorys=Category.objects.all()
    return render(request,"cattab.html",{'categorys':categorys})



#state 
def slist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    states=State.objects.all()
    return render(request,"statetab.html",{'states':states})

def sdel(request,id):
    s=State.objects.get(sid=id)
    s.delete()
    return redirect("/statetab/")

def sedit(request,id):
    s=State.objects.get(sid=id)
    return render(request,"sedit.html",{'State':s})
    
def supdate(request,id):
    s=State.objects.get(sid=id)
    name= request.POST.get('sname')
    s.sname=name
    s.save()
    return redirect("/statetab/")

def sadd(request):
    return render(request,"stateadd.html")

def ssave(request):
    name=request.POST.get('sname')
    State.objects.create(sname=name)
    return redirect("/statetab/")

def statetab(request):
    states=State.objects.all()
    return render(request,"statetab.html",{'states':states})    
#unit

def ulist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    units=Unit.objects.all()
    return render(request,"ulist.html",{'units':units})

def udel(request,id):
     u=Unit.objects.get(uid=id)
     u.delete()
     return redirect("/ulist/")

def uedit(request,id):
    u=Unit.objects.get(uid=id)
    return render(request,"uedit.html",{'Unit':u})
    
def uupdate(request,id):
    u=Unit.objects.get(uid=id)
    name= request.POST.get('uname')
    u.uname=name
    u.save()
    return redirect("/ulist/")

def uadd(request):
    return render(request,"uadd.html")

def usave(request):
    name=request.POST.get('uname')
    Unit.objects.create(uname=name)
    return redirect("/ulist/")

#area

def arealist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    areas=Area.objects.all()
    return render(request,"arealist.html",{'areas':areas})

def areaadd(request):
    citys=City.objects.all()
    return render(request,"areaadd.html",{'citys':citys})

def areasave(request):
    
    name = request.POST.get('area_name')
    pincode = request.POST.get('pincode')
    c_id = request.POST.get('c_id')
    Area.objects.create(area_name=name,pincode=pincode,c_id=c_id)
    return redirect("/arealist/")

def areaedit(request,id):
    a=Area.objects.get(pincode=id)
    citys=City.objects.all()
    return render(request,"areaedit.html",{'a':a,'citys':citys})

def areaupdate(request,id):
    a=Area.objects.get(pincode=id)
    name= request.POST.get('area_name')
    city=request.POST.get('c_id')
    ct=City.objects.get(c_id=city)
    a.c_id=ct
    a.area_name=name
    a.save()
    return redirect("/arealist/")

def areadel(request,id):
     a=Area.objects.get(pincode=id)
     a.delete()
     return redirect("/arealist/")


#product

def prodlist(request,id):
    p=ProductSubcategory.objects.get(subcat_id=id)
    product = Product.objects.filter(subcat=p)
    return render(request,"productlist.html",{'products':product})


def productlist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    product = Product.objects.all()
    return render(request,"productlist.html",{'products':product})

def productreport(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    if request.method=="POST":
        search=request.POST.get("search")
        product=Product.objects.filter(p_name__icontains=search)
        return render(request,"productreport.html",{'products':product})
    product = Product.objects.all()
    return render(request,"productreport.html",{'products':product})

    


def vproductlist(request):
    if request.session.has_key("cid")==False:
        link=False
    else:
        link=True
   
    product = Product.objects.all()
    categorys=Category.objects.all()
    

    

    return render(request,"visitor/shop.html",{'products':product, 'categorys':categorys,"link":link})

def productadd(request):
    productsubcategorys=ProductSubcategory.objects.all()
    return render(request,"productadd.html",{'productsubcategorys':productsubcategorys})

def productdel(request,id):
     p=Product.objects.get(p_id=id)
     p.delete()
     return redirect("/productlist/")

def productedit(request,id):
     p=Product.objects.get(p_id=id)
     productsubcategorys=ProductSubcategory.objects.all()
     return render(request,"productedit.html",{'p':p,'productsubcategorys':productsubcategorys})

def vproductedit(request,id):
     p=Product.objects.get(p_id=id)
     productsubcategorys=ProductSubcategory.objects.all()
     return render(request,"visitor/shop-detail.html",{'p':p,'productsubcategorys':productsubcategorys})


def productsave(request):
   if request.method == 'POST':
        name = request.POST.get('p_name')
        description = request.POST.get('p_description')
        subcat = request.POST.get('subcat_id')
        price = request.POST.get('p_price')
        shelf_life = request.POST.get('p_shelf_life')

        # Handle image upload
        imgurl = None  # Default to None if no image is provided
        if 'p_image' in request.FILES:
            cfile = request.FILES['p_image']
            fss = FileSystemStorage()
            sfile = fss.save(cfile.name, cfile)
            imgurl = fss.url(sfile)

        # Get subcategory
        s = ProductSubcategory.objects.get(subcat_id=subcat)

        # Create product
        Product.objects.create(
            p_name=name,
            p_image=imgurl,
            p_description=description,
            subcat=s,
            p_price=price,
            p_shelf_life=shelf_life
        )
        return redirect("/productlist/")
def productupdate(request,id):
    p = Product.objects.get(p_id=id)

    # Retrieve form data
    name = request.POST.get('p_name')
    description = request.POST.get('p_description')
    subcat = request.POST.get('subcat_id')
    price = request.POST.get('p_price')
    shelf_life = request.POST.get('p_shelf_life')

    # Handle subcategory safely
    try:
        s = ProductSubcategory.objects.get(subcat_id=subcat)
        p.subcat = s
    except ProductSubcategory.DoesNotExist:
        pass  # If the subcategory doesn't exist, do nothing

    # Handle image upload safely
    if 'p_image' in request.FILES:
        try:
            cfile = request.FILES["p_image"]
            fss = FileSystemStorage()
            sfile = fss.save(cfile.name, cfile)
            imgurl = fss.url(sfile)
            p.p_image = imgurl  # Update only if a new image is uploaded
        except MultiValueDictKeyError:
            pass  # Keep the existing image if upload fails
    # If no new image is uploaded, p.p_image retains its old value automatically

    # Update other fields
    p.p_name = name
    p.p_description = description
    p.p_price = price
    p.p_shelf_life = shelf_life

    p.save()
    return redirect("/productlist/") 
#product packing

def poclist(request,id):
    p=Product.objects.get(p_id=id)
    productpackings = ProductPacking.objects.filter(p_id= p)
    return render(request,"productpackinglist.html",{'productpackings':productpackings})
    
def vpoclist(request,id):
    if request.session.has_key("cid")==False:
        link=False
    else:
        link=True
    
    p=Product.objects.get(p_id=id)
    productpackings = ProductPacking.objects.filter(p_id= p)
    return render(request,"visitor/Product-detail.html",{'productpackings':productpackings,"link":link})

def vproductdescription(request,id):
    if request.session.has_key("cid")==False:
        link=False
    else:
        link=True
   
    productpacking = ProductPacking.objects.get(pack_id= id)
    return render(request,"visitor/shop-detail.html",{'p':productpacking,"link":link})

def productpackinglist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    productpackings=ProductPacking.objects.all()
    return render(request,"productpackinglist.html",{'productpackings':productpackings})

def vproductpackinglist(request):
    productpackings=ProductPacking.objects.all()
    return render(request,"visitor/shop-detail.html",{'productpackings':productpackings})

def productpackingadd(request):
    units=Unit.objects.all()
    products = Product.objects.all()
    return render(request,"productpackingadd.html",{'units':units,'products':products})


def productpackingsave(request):
    product=request.POST.get('p_id')
    price=request.POST.get('pack_price')
    cfile=request.FILES["pack_image"]
    fss=FileSystemStorage()
    sfile=fss.save(cfile.name,cfile)
    imgurl=fss.url(sfile)
    un=request.POST.get('uid')
    un=Unit.objects.get(uid=un)
    product = Product.objects.get(p_id=product)
    ProductPacking.objects.create(p=product,pack_price=price,pack_image=imgurl,uid=un)
    return redirect("/productpackinglist/")

def productpackingdel(request,id):
    p = ProductPacking.objects.get(pack_id= id)
    p.delete()
    return redirect("/productpackinglist/")

def productpackingedit(request,id):
    p =ProductPacking.objects.get(pack_id= id)
    units=Unit.objects.all()
    products = Product.objects.all()
    return render(request,"productpackingedit.html",{'p':p,'units':units,'products':products})

def productpackingupdate(request,id):
    pac =ProductPacking.objects.get(pack_id= id)
    product=request.POST.get('p_id')
    price=request.POST.get('pack_price')
    cfile=request.FILES["pack_image"]
    fss=FileSystemStorage()
    sfile=fss.save(cfile.name,cfile)
    imgurl=fss.url(sfile)
    unit_id=request.POST.get('uid')
    uid = Unit.objects.get(uid=unit_id)
    product = Product.objects.get(p_id=product)

    pac.p = product
    pac.pack_price = price
    pac.pack_image =imgurl
    pac.uid= uid
    pac.save()
    return redirect("/productpackinglist/")



#ProductSubcategory

def codlist(request,id):
    c=Category.objects.get(cid=id)
    productsubcategorys=ProductSubcategory.objects.filter(cat=c)
    return render(request,"productsubcategorylist.html",{'productsubcategorys':productsubcategorys})



def productsubcategorylist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    productsubcategorys=ProductSubcategory.objects.all()
    return render(request,"productsubcategorylist.html",{'productsubcategorys':productsubcategorys})

def productsubcategoryadd(request):
    categorys = Category.objects.all()
    return render(request,"productsubcategoryadd.html",{'categorys':categorys})

def productsubcategorysave(request):
    id =request.POST.get('subcat_id')
    name=request.POST.get('sub_name')
    cfile=request.FILES["sub_image"]
    fss=FileSystemStorage()
    sfile=fss.save(cfile.name,cfile)
    imgurl=fss.url(sfile)
    cid=request.POST.get('cat')
    ct =Category.objects.get(cid=cid)
    ProductSubcategory.objects.create(subcat_id=id,sub_name=name,sub_image=imgurl,cat=ct)
    return redirect("/productsubcategorylist/")

# def productsubcategoryupdate(request,id):
#     p=ProductSubcategory.objects.get(subcat_id=id)
#     name= request.POST.get('sub_name')
#     cfile=request.FILES["sub_image"]
#     fss=FileSystemStorage()
#     sfile=fss.save(cfile.name,cfile)
#     imgurl=fss.url(sfile)   
#     cat=request.POST.get('cat')
#     ct=Category.objects.get(cid=cat)
#     p.sub_name=name
#     p.sub_image=imgurl
#     p.cat=ct
#     p.save()
#     return redirect("/productsubcategorylist/")

def productsubcategoryupdate(request, id):
    p = ProductSubcategory.objects.get(subcat_id=id)
    
    name = request.POST.get('sub_name')
    cat = request.POST.get('cat')
    ct = Category.objects.get(cid=cat)
    
    # Check if new image is provided
    if 'sub_image' in request.FILES:
        cfile = request.FILES["sub_image"]
        fss = FileSystemStorage()
        sfile = fss.save(cfile.name, cfile)
        imgurl = fss.url(sfile)
        p.sub_image = imgurl
    
    p.sub_name = name
    p.cat = ct
    p.save()
    return redirect("/productsubcategorylist/")

def productsubcategorydel(request,id):
     p=ProductSubcategory.objects.get(subcat_id=id)
     p.delete()
     return redirect("/productsubcategorylist/")

def productsubcategoryedit(request,id):
    p=ProductSubcategory.objects.get(subcat_id=id)
    categorys =Category.objects.all()
    return render(request,"productsubcategoryedit.html",{'p':p,'categorys':categorys})

#Production

def productionlist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    production=Production.objects.all()
    return render(request,"productionlist.html",{'productions':production})


def productionsave(request):
    
    production_id=request.POST.get('production_id')
    batch_no=request.POST.get('batch_no')
    production_date=request.POST.get('production_date')
    emp_id=request.POST.get('emp')
    em = Employee.objects.get(emp_id=emp_id)
    description=request.POST.get('description')
    status=request.POST.get('status')
    Production.objects.create(production_id=production_id,batch_no=batch_no,production_date=production_date,emp=em,description=description,status=status)
    return redirect("/productionlist/")

def productionupdate(request,id):
    p=Production.objects.get(production_id=id)
    
    batch_no=request.POST.get('batch_no')
    production_date=request.POST.get('production_date')
    emp=request.POST.get('emp_id')
    em = Employee.objects.get(emp_id=emp)
    description=request.POST.get('description')
    status=request.POST.get('status')
    p.batch_no=batch_no
    p.production_date = production_date
    p.emp= em
    p.description = description
    p.status = status
    p.save()
    return redirect("/productionlist/")

def productiondelete(request,id):
    p=Production.objects.get(production_id=id)
    p.delete()
    return redirect("/productionlist/")
    



def productionedit(request,id):
    p=Production.objects.get(production_id=id)
    employees =Employee.objects.all()
    return render(request,"productionedit.html",{'p':p,'employees' : employees})


#ProductionProduct

def ppodlist(request,id):

    p=Production.objects.get(production_id=id)
    productionproduct=ProductionProduct.objects.filter(production=p)
    return render(request,"productionproductlist.html",{'productionproducts':productionproduct})


def productionproductlist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    productionproduct=ProductionProduct.objects.all()
    return render(request,"productionproductlist.html",{'productionproducts':productionproduct})

def productionproductadd(request):
    production=Production.objects.all()
    productpackings=ProductPacking.objects.all()
    return render(request,"productionproductadd.html",{'productions':production,'productpackings':productpackings})

def productionproductdel(request,id):
    p=ProductionProduct.objects.get(production_p_id=id)
    p.delete()
    return redirect("/productionproductlist/")

def productionproductedit(request,id):
    p=ProductionProduct.objects.get(production_p_id=id)
    productions=Production.objects.all()
    return render(request,"productionproductedit.html",{'p':p,'productions':productions})
    
def productionproductupdate(request,id):
    p=ProductionProduct.objects.get(production_p_id=id)
    production= request.POST.get('production')
    quantity= request.POST.get('quantity')
    pack= request.POST.get('pack')
    productions=Production.objects.get(production=productions)

    p.production=production
    p.quantity= quantity
    p.pack=pack
    p.save()
    return redirect("/productionproductlist/")

def productionproductsave(request):
    Production=request.POST.get('production')
    production_p_id=request.POST.get('production_p_id')
    quantity=request.POST.get('quantity')
    pack=request.POST.get('pack') 
    pd=Production.objects.get(production=pd)  
    pack=ProductPacking.objects.get(pack=pack)          
    ProductionProduct.objects.create(production=Production,production_p_id=production_p_id,quantity=quantity,pack=pd)
    return redirect("/productionproductlist/")





    #ProductionStock

def productionstocklist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    productionstock=ProductionStock.objects.all()
    return render(request,"productionstocklist.html",{'productionstocks':productionstock})
def productionstockadd(request):
    production=Production.objects.all()
    productionproducts = ProductionProduct.objects.all()
    return render(request,"productionstockadd.html",{'productions':production,'productionproducts':productionproducts})


def productionstocksave(request):
    p_stock_id=request.POST.get('p_stock_id')
    production_p=request.POST.get('production_p')
    productionproducts = ProductionProduct.objects.get(production_p=productionproducts)
    qunatity=request.POST.get('qunatity')
    stock_date=request.POST.get('stock_date')
    production=request.POST.get('production')
    productions = Production.objects.get(production=productions)
    ProductionStock.objects.create(p_stock_id=p_stock_id,production_p=production_p,qunatity=qunatity,stock_date=stock_date,production=production)
    return redirect("/productionstocklist/")

def productionstockedit(request,id):
    p =ProductionStock.objects.get(p_stock_id= id)
    productions=Production.objects.all()
    productionproducts = ProductionProduct.objects.all()
    
    return render(request,"productionstockedit.html",{'p':p,'productionproducts':productionproducts,'productions':productions})

def productionstockupdate(request,id):
    p =ProductionStock.objects.get(p_stock_id= id)
    p_stock_id=request.POST.get('p_stock_id')
    production_p=request.POST.get('production_p')
    productionproducts = ProductionProduct.objects.get(production_p=productionproducts)
    qunatity=request.POST.get('qunatity')
    stock_date=request.POST.get('stock_date')
    production=request.POST.get('production')
    production = Production.objects.get(production=production)

    p.p_stock_id = p_stock_id
    p.production_p = production_p
    p.qunatity =qunatity
    p.stock_date=stock_date
    p.production= production
    p.save()
    return redirect("/productionstocklist/")


#Purchase

def purchaselist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    purchases=Purchase.objects.all()
    return render(request,"purchaselist.html",{'purchases':purchases})

# def purchaseadd(request):
#     supplier=Supplier.objects.all()
#     return render(request,"purchaseadd.html",{'suppliers':supplier})

# def purchasesave(request):
#     purchase_id=request.POST.get('purchase_id')
#     purchase_date=request.POST.get('purchase_date')
#     Supplier=request.POST.get('sup')
#     status=request.POST.get('status')
#     total=request.POST.get('total')
#     supplier=Supplier.objects.get(sup=Supplier)
#     Purchase.objects.create(purchase_id=purchase_id,purchase_date=purchase_date,sup=supplier,status=status,total=total)
#     return redirect("/purchaselist/")
def purchaseadd(request):
    suppliers = Supplier.objects.all()
    return render(request, "purchaseadd.html", {'suppliers': suppliers})
def purchasesave(request):
    if request.method == 'POST':
        purchase_id = request.POST.get('purchase_id')
        purchase_date = request.POST.get('purchase_date')
        supplier_id = request.POST.get('sup_id')  # Correct field
        status = request.POST.get('status')
        total = request.POST.get('total')

        try:
            supplier = Supplier.objects.get(sup_id=supplier_id)  # <-- Corrected here
            Purchase.objects.create(
                purchase_id=purchase_id,
                purchase_date=purchase_date,
                sup=supplier,
                status=status,
                total=total
            )
            return redirect("/purchaselist/")
        except Supplier.DoesNotExist:
            # Supplier nahi mila toh error dikha
            return render(request, "purchaseadd.html", {
                'suppliers': Supplier.objects.all(),
                'error': "Invalid supplier selected."
            })
    return redirect("/purchaselist/")  # Agar POST nahi hai toh list pe bhej do


def purchasedel(request,id):
    p= Purchase.objects.get(purchase_id=id)
    p.delete()
    return redirect("/purchaselist/")

def purchaseedit(request,id):
    p= Purchase.objects.get(purchase_id=id)
    supplier=Supplier.objects.all()
    return render(request,"purchaseedit.html",{'p':p,'suppliers':supplier})

def purchaseupdate(request,id):
    p= Purchase.objects.get(purchase_id=id)
    purchase_date=request.POST.get('purchase_date')
    supplier=request.POST.get('Supplier')
    status=request.POST.get('status')
    total=request.POST.get('total')
    supplier=Supplier.objects.get(sup_id=supplier)
    
    p.purchase_date=purchase_date
    p.sup=supplier
    p.status=status
    p.total=total
    p.save()
    return redirect("/purchaselist/")

#PurchaseDesc

def purchasedesclist(reuqest):
    purchasedesc=PurchaseDesc.objects.all()
    return render(reuqest,"purchasedesclist.html",{'purchasedescs':purchasedesc})

def podlist(requset,id):
    purchase= Purchase.objects.get(purchase_id=id)
    purchasedesc=PurchaseDesc.objects.filter(purchase=purchase)
    return render(requset, "purchasedesclist.html", {'purchasedescs':purchasedesc})


def purchasedescadd(request):
    rawmaterials = RawMaterial.objects.all()
    purchases=Purchase.objects.all()
    return render(request,"purchasedescadd.html",{'rawmaterials':rawmaterials,'purchases':purchases})

def purchasedescsave(request):
    purchase_d_id=request.POST.get('purchase_d_id')
    purchase=request.POST.get('purchase')
    quantity=request.POST.get('quantity')
    rate=request.POST.get('rate')
    rm_id=request.POST.get('rm_id')
    purchase=Purchase.objects.get(purchase_id=purchase)
    rm = RawMaterial.objects.get(rm_id=rm_id)
    PurchaseDesc.objects.create(purchase_d_id=purchase_d_id,purchase=purchase,quantity=quantity,rate=rate,rm_id=rm)
    return redirect("/purchasedesclist/")

def purchasedescupdate(request,id):
    p=PurchaseDesc.objects.get(purchase_d_id=id)
    
    purchase= request.POST.get('purchase')
    quantity=request.POST.get('quantity')
    rate=request.POST.get('rate')
    rm_id=request.POST.get('rm_id')
    rm = RawMaterial.objects.get(rm_id=rm_id)
    purchase=Purchase.objects.get(purchase_id=purchase)
    p.purchase=purchase
    p.quantity=quantity
    p.rate=rate
    p.rm=rm
    p.save()
    return redirect("/purchasedesclist/")

def purchasedescdel(request,id):
     p=PurchaseDesc.objects.get(purchase_d_id=id)
     p.delete()
     return redirect("/purchasedesclist/")

def purchasedecsedit(request,id):
    p=PurchaseDesc.objects.get(purchase_d_id=id)
    purchases=Purchase.objects.all()
    rawmaterials = RawMaterial.objects.all()
    return render(request,"purchasedecsedit.html",{'p':p,'rawmaterials':rawmaterials,'purchases':purchases})

#RawMaterial

def rawmateriallist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    rawmaterials=RawMaterial.objects.all()
    return render(request,"rawmateriallist.html",{'rawmaterials':rawmaterials})

def rawmaterialadd(request):
    units=Unit.objects.all()
    return render(request,"rawmaterialadd.html" ,{'units':units})

def rawmaterialsave(request):
    rm_id=request.POST.get('rm_id')
    rm_name=request.POST.get('rm_name')
    rm_descripition=request.POST.get('rm_descripition')
    uid=request.POST.get('unit')
    uid=Unit.objects.get(uid=uid)
    RawMaterial.objects.create(rm_id=rm_id,rm_name=rm_name,rm_descripition=rm_descripition,uid=uid)
    return redirect("/rawmateriallist/")

def rawmaterialdel(request,id):
    r = RawMaterial.objects.get(rm_id= id)
    r.delete()
    return redirect("/rawmateriallist/")

def rawmaterialedit(request,id):
    r = RawMaterial.objects.get(rm_id= id)
    units=Unit.objects.all()
    return render(request,"rawmaterialedit.html",{'r':r,'units':units})

def rawmaterialupdate(request,id):
    r = RawMaterial.objects.get(rm_id= id)
    name=request.POST.get('rm_name')
    rm_descripition=request.POST.get('rm_descripition')
    uid=request.POST.get('unit')
    uid=Unit.objects.get(uid=uid)
    r.rm_name = name
    r.rm_descripition = rm_descripition
    r.uid =uid
    r.save()
    return redirect("/rawmateriallist/")

#Sell
def selllist(request):
    if "a_id" not in request.session:
        messages.error(request, "Please log in as admin.")
        return redirect("/alogin/")
    sell = Sell.objects.all()
    return render(request, "selllist.html", {'sells': sell})


def sellreport(request):
    if "a_id" not in request.session:
        messages.error(request, "Please log in as admin.")
        return redirect("/alogin/")
    if request.method == "POST":
        search = request.POST.get("search")
        if search:
            # Assuming sell_id is an integer, using exact match
            sell = Sell.objects.filter(sell_id__exact=search)
        else:
            sell = Sell.objects.all()
        return render(request, "sellreport.html", {'sells': sell})
    
    sell = Sell.objects.all()
    return render(request, "sellreport.html", {'sells': sell})


def sellsave(request):
    if request.method == "POST":
        total = request.POST.get('total')
        sell_date = request.POST.get('sell_date')
        cust_id = request.POST.get('cust')
        docket_num = request.POST.get('docket_num') or None  # Save None if empty
        track_url = request.POST.get('track_url') or None   # Save None if empty
        status = request.POST.get('status')

        # Validate required fields
        if not (total and sell_date and cust_id and status):
            messages.error(request, "Total, sell date, customer, and status are required.")
            return redirect("/selllist/")  # Redirect back to sell list or form

        try:
            c = Customer.objects.get(cust_id=cust_id)
            Sell.objects.create(
                total=total,
                sell_date=sell_date,
                cust=c,
                docket_num=docket_num,
                track_url=track_url,
                status=status
            )
            messages.success(request, "Sell record saved successfully.")
        except Customer.DoesNotExist:
            messages.error(request, "Invalid customer selected.")
        except Exception as e:
            messages.error(request, f"Error saving sell record: {str(e)}")
    
    return redirect("/selllist/")


def selledit(request, id):
    try:
        s = Sell.objects.get(sell_id=id)
        customers = Customer.objects.all()
        return render(request, "selledit.html", {'s': s, 'customers': customers})
    except Sell.DoesNotExist:
        messages.error(request, "Sell record not found.")
        return redirect("/selllist/")


def sellupdate(request, id):
    if request.method == "POST":
        try:
            s = Sell.objects.get(sell_id=id)
            total = request.POST.get('total')
            sell_date = request.POST.get('sell_date')
            cust_id = request.POST.get('cust_id')
            docket_num = request.POST.get('docket_num') or None  # Save None if empty
            track_url = request.POST.get('track_url') or None   # Save None if empty
            status = request.POST.get('status')

            # Validate required fields
            if not (total and sell_date and status):
                messages.error(request, "Total, sell date, and status are required.")
                return redirect("/selledit/" + str(id))

            # Update fields
            s.total = total
            s.sell_date = sell_date
            s.docket_num = docket_num
            s.track_url = track_url
            s.status = status

            # Update customer if provided
            if cust_id:
                try:
                    c = Customer.objects.get(cust_id=cust_id)
                    s.cust = c
                except Customer.DoesNotExist:
                    messages.warning(request, "Invalid customer selected; retaining previous customer.")

            s.save()
            messages.success(request, "Sell record updated successfully.")
        except Sell.DoesNotExist:
            messages.error(request, "Sell record not found.")
        except Exception as e:
            messages.error(request, f"Error updating sell record: {str(e)}")
    
    return redirect("/selllist/")
#SellDetail

def selldetaillist(requset):
    
    selldetail = SellDetail.objects.all()
    return render(requset, "selldetaillist.html", {'selldetails': selldetail})
def sodlist(requset,id):
    sell=Sell.objects.get(sell_id=id)
    selldetail = SellDetail.objects.filter(sell=sell)
    return render(requset, "selldetaillist.html", {'selldetails': selldetail})

def selldetailadd(request):
    productpackings=ProductPacking.objects.all()
    sell=Sell.objects.all()
    return render(request,"selldetailadd.html",{'productpackings':productpackings,'sells':sell})

def selldetailedit(request,id):
    s=SellDetail.objects.get(sd_id=id)
    productpackings=ProductPacking.objects.all()
    sell=Sell.objects.all()
    return render(request,"selldetailedit.html",{'s':s,'productpackings':productpackings,'sells':sell })

def selldetailupdate(request,id):
    s=SellDetail.objects.get(sd_id=id)
    sell_id=request.POST.get('sell_id')
    sell=request.POST.get('sell')
    quantity=request.POST.get('quantity')
    rate=request.POST.get('rate')
    pack=request.POST.get('pack')
    pk=ProductPacking.objects.get(pack=pack)

    s.sd_id=sell_id
    s.sell=sell
    s.quantity=quantity
    s.rate=rate
    s.pack=pk
    s.save()
    return redirect("/selldetaillist/")

def selldetaildel(request,id):
     s=SellDetail.objects.get(sell_id=id)
     s.delete()
     return redirect("/selldetaillist/")

def selldetailsave(request):
    sell_id=request.POST.get('sell_id')
    sell=request.POST.get('sell')
    quantity=request.POST.get('quantity')
    rate=request.POST.get('rate')
    pack=request.POST.get('pack')
    pk=ProductPacking.objects.get(pack=pack)
    SellDetail.objects.create(sell_id=sell_id,sell=sell,quantity=quantity,rate=rate,pack=pk)
    return redirect("/selldetaillist/")


#Supplier

def supplierlist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    
    suppliers=Supplier.objects.all()
    return render(request,"supplierlist.html",{'suppliers':suppliers})

def supplieradd(request):
    areas = Area.objects.all()
    return render(request,"supplieradd.html",{'areas':areas})

def suppliersave(request):
    supplier_id=request.POST.get('sup_id')
    name=request.POST.get('sup_name')
    address=request.POST.get('sup_address')
    contact=request.POST.get('sup_contact')
    email=request.POST.get('sup_email')
    pincode = request.POST.get('pincode')
    a = Area.objects.get(pincode=pincode)
    Supplier.objects.create(sup_id=supplier_id,sup_name=name,sup_address=address,sup_contact=contact,sup_email=email,pincode=a)
    return redirect("/supplierlist/")

def supplieredit(request,id):
    s=Supplier.objects.get(sup_id=id)
    areas = Area.objects.all()
    return render(request,"supplieredit.html",{'s':s,'areas':areas})

def supplierupdate(request,id):
    s=Supplier.objects.get(sup_id=id)
    name=request.POST.get('sup_name')
    address=request.POST.get('sup_address')
    contact=request.POST.get('sup_contact')
    email=request.POST.get('sup_email')
    pincode = request.POST.get('pincode')
    a = Area.objects.get(pincode=pincode)
    s.sup_name=name
    s.sup_address=address
    s.sup_contact=contact
    s.sup_email=email
    s.pincode = a
    s.save()
    return redirect("/supplierlist/")

def supplierdel(request,id):
     s=Supplier.objects.get(sup_id=id)
     s.delete()
     return redirect("/supplierlist/")


#city



def citylist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    
    citys=City.objects.all()
    return render(request,"citylist.html",{'citys':citys})

def cityadd(request):
    states=State.objects.all()
    return render(request,"cityadd.html",{'states':states})

def citydel(request,id):
    c= City.objects.get(c_id = id)
    c.delete()
    return redirect("/citylist/")

def cityedit(request,id):
    c= City.objects.get(c_id = id)
    states=State.objects.all()
    return render(request,"cityedit.html",{'c':c,'states':states})

def cityupdate(request,id):
    c= City.objects.get(c_id = id)
    name =request.POST.get('c_name')
    sid=request.POST.get('sid')
    st=State.objects.get(sid=sid)    
    c.c_name = name
    c.sid =st
    c.save()
    return redirect("/citylist/")


def citysave(request):
    
    name=request.POST.get('c_name')
    sid=request.POST.get('sid')
    st=State.objects.get(sid=sid)    
    City.objects.create(c_name=name,sid=st)
    return redirect("/citylist/")

#customer

def customerlist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/") 
    customer=Customer.objects.all()
    return render(request,"customerlist.html",{'customers':customer})

def customerreport(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/") 
    if request.method=="POST":
        search=request.POST.get("search")
        customer=Customer.objects.filter(cust_name__icontains=search)
        return render(request,"customerreport.html",{'customers':customer})

    customer=Customer.objects.all()
    return render(request,"customerreport.html",{'customers':customer})

def customerdel(request,id):
    c= Customer.objects.get(cust_id = id)
    c.delete()
    return redirect("/customerlist/")

def customeredit(request,id):
    c= Customer.objects.get(cust_id = id)
    areas = Area.objects.all()
    return render(request,"customeredit.html",{'c':c,'areas':areas})

def customerupdate(request,id):
    c= Customer.objects.get(cust_id = id)
     # Retrieve form data
    name = request.POST.get('cust_name')
    dateofbirth = request.POST.get('cust_dob')
    contact = request.POST.get('cust_contact')
    email = request.POST.get('cust_email')
    password = request.POST.get('cust_password')
    address = request.POST.get('cust_address')
    pincode = request.POST.get('pincode')

    # Update fields
    c.cust_name = name
    c.cust_dob = dateofbirth
    c.cust_contact = contact
    c.cust_email = email
    c.cust_password = password
    c.cust_address = address

    # Handle image update safely
    try:
        cfile = request.FILES["cust_image"]
        fss = FileSystemStorage()
        sfile = fss.save(cfile.name, cfile)
        imgurl = fss.url(sfile)
        c.cust_image = imgurl  # Update only if a new image is uploaded
    except MultiValueDictKeyError:
        pass  # Keep the existing image if no new one is uploaded

    # Handle Area (if pincode exists)
    try:
        areas = Area.objects.get(pincode=pincode)
        c.pincode = areas
    except Area.DoesNotExist:
        pass  # Handle the case where the pincode is not found

    c.save()
    return redirect("/customerlist/")

def customersave(request):
    name=request.POST.get('cust_name')
    dateofbirth=request.POST.get('cust_dob')
    contact=request.POST.get('cust_contact')
    email=request.POST.get('cust_email')
    cfile=request.FILES["cust_image"]
    fss=FileSystemStorage()
    sfile=fss.save(cfile.name,cfile)
    imgurl=fss.url(sfile)
    password=request.POST.get('cust_password')
    address=request.POST.get('cust_address')
    pincode=request.POST.get('pincode')
    areas = Area.objects.get(pincode=pincode)
    
    Customer.objects.create(cust_name=name,cust_dob=dateofbirth,cust_contact=contact,cust_email=email,cust_image=imgurl,cust_password=password,cust_address=address,pincode=areas)
    return redirect("/customerlist/")

#employee

def employeelist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    
    employee=Employee.objects.all()
    return render(request,"employeelist.html",{'employees':employee})
def employeereport(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    if request.method=="POST":
        search=request.POST.get("search")
        employee=Employee.objects.filter(emp_name__icontains=search)
        return render(request,"employeereport.html",{'employees':employee})

    employee=Employee.objects.all()
    return render(request,"employeereport.html",{'employees':employee})

def employeeadd(request):
    areas=Area.objects.all()
    return render(request,"employeeadd.html",{'areas':areas})

def employeesave(request):
    if request.method == "POST":
        employee_id = request.POST.get('emp_id')
        name = request.POST.get('emp_name')
        email = request.POST.get('emp_email')
        contact = request.POST.get('emp_contact')
        password = request.POST.get('emp_password')
        address = request.POST.get('emp_address')
        dateofbirth = request.POST.get('emp_d0b')
        dateofjoining = request.POST.get('emp_doj')
        pincode = request.POST.get('pincode')

        # Handle pincode lookup safely
        try:
            areas = Area.objects.get(pincode=pincode)
        except Area.DoesNotExist:
            areas = None  # If pincode is invalid, set it to None

        # Handle image upload safely
        imgurl = None
        try:
            cfile = request.FILES["emp_image"]
            fss = FileSystemStorage()
            sfile = fss.save(cfile.name, cfile)
            imgurl = fss.url(sfile)
        except MultiValueDictKeyError:
            pass  # Keep imgurl as None if no file is uploaded

        # Create Employee
        Employee.objects.create(
            emp_id=employee_id,
            emp_name=name,
            emp_email=email,
            emp_contact=contact,
            emp_password=password,
            emp_image=imgurl,  # Image will be None if not uploaded
            emp_address=address,
            emp_d0b=dateofbirth,
            emp_doj=dateofjoining,
            pincode=areas
        )

        return redirect("/employeelist/")

def employeedel(request,id):
    e = Employee.objects.get(emp_id= id)
    e.delete()
    return redirect("/employeelist/")

def employeeedit(request,id):
    e = Employee.objects.get(emp_id= id)
    areas=Area.objects.all()
    return render(request,"employeeedit.html",{'e':e,'areas':areas})

def employeeupdate(request,id):
    e = Employee.objects.get(emp_id=id)

    # Retrieve form data
    name = request.POST.get('emp_name')
    email = request.POST.get('emp_email')
    contact = request.POST.get('emp_contact')
    password = request.POST.get('emp_password')
    address = request.POST.get('emp_address')
    dateofbirth = request.POST.get('emp_d0b')
    dateofjoining = request.POST.get('emp_doj')
    pincode = request.POST.get('Pincode')

    # Handle file upload safely
    try:
        cfile = request.FILES["emp_image"]
        fss = FileSystemStorage()
        sfile = fss.save(cfile.name, cfile)
        imgurl = fss.url(sfile)
        e.emp_image = imgurl  # Update only if a new image is uploaded
    except MultiValueDictKeyError:
        pass  # Keep the existing image if no new one is uploaded

    # Handle Area update safely
    try:
        areas = Area.objects.get(pincode=pincode)
        e.pincode = areas
    except Area.DoesNotExist:
        pass  # If the pincode is invalid, do nothing

    # Update other fields
    e.emp_name = name
    e.emp_email = email
    e.emp_contact = contact
    e.emp_password = password
    e.emp_address = address
    e.emp_d0b = dateofbirth
    e.emp_doj = dateofjoining

    e.save()
    

    return redirect("/employeelist/")
#RmStock

def rmstocklsit(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    
    rmstock=RmStock.objects.all()
    return render(request,"rmstocklist.html",{'rmstocks':rmstock})

def rmstockadd(request):
    units=Unit.objects.all()
    rawmaterials=RawMaterial.objects.all()
    return render(request,"rmstockadd.html",{'units':units,'rawmaterials':rawmaterials})

def rmstockdel(request,id):
    r = RmStock.objects.get(rm_stock_id= id)
    r.delete()
    return redirect("/rmstocklist/")

def rmstockedit(request,id):
    r = RmStock.objects.get(rm_stock_id= id)
    units=Unit.objects.all()
    rawmaterials=RawMaterial.objects.all()
    return render(request,"rmstockedit.html",{'r':r,'units':units,'rawmaterials':rawmaterials})

def rmstockupdate(request,id):
    r = RmStock.objects.get(rm_stock_id= id)
    rm_stock_id=request.POST.get('rm_stock_id')
    rawmaterial=request.POST.get('RawMaterial')
    stock_date=request.POST.get('stock_date')
    quantity=request.POST.get('quantity')
    uid=request.POST.get('unit')
    uid=Unit.objects.get(uid=uid)
    rawmaterial=RawMaterial.objects.get(rm_id=rawmaterial)

    r.rm_stock_id = rm_stock_id
    r.rm = rawmaterial
    r.stock_date = stock_date
    r.quantity = quantity
    r.uid =uid
    
    r.save()
    return redirect("/rmstocklist/")


def rmstocksave(request):
    rm_stock_id=request.POST.get('rm_stock_id')
    rawmaterial=request.POST.get('rm')
    stock_date=request.POST.get('stock_date')
    quantity=request.POST.get('quantity')
    unid=request.POST.get('unit')
    uid=Unit.objects.get(uid=unid)
    rawmaterial=RawMaterial.objects.get(rm_id=rawmaterial)
    RmStock.objects.create(rm_stock_id=rm_stock_id,rm=rawmaterial,stock_date=stock_date,quantity=quantity,uid=uid)
   
    return redirect("/rmstocklist/")

#ProductionRm

def productionrmlist(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    
    productionrm=ProductionRm.objects.all()
    return render(request,"productionrmlist.html",{'productionrms':productionrm})

def productionrmadd(request):
    units=Unit.objects.all()
    rawmaterials=RawMaterial.objects.all()
    products = Product.objects.all()
    productions=Production.objects.all()
    return render(request,"productionrmadd.html",{'units':units,'rawmaterials':rawmaterials,'products':products,'productions':productions})

def productionrmdel(request,id):
    p=ProductionRm.objects.get(p_rm_id=id)
    p.delete()
    return redirect("/productionrmlist/")

def productionrmedit(request,id):
    p=ProductionRm.objects.get(p_rm_id=id)
    units=Unit.objects.all()
    rawmaterials=RawMaterial.objects.all()
    products = Product.objects.all()
    productions=Production.objects.all()
    return render(request,"productionrmedit.html",{'p':p,'units':units,'rawmaterials':rawmaterials,'products':products,'productions':productions})
    
def productionrmupdate(request, id):
    if request.method == 'POST':
    
            p = ProductionRm.objects.get(p_rm_id=id)

            p_rm_description = request.POST.get('p_rm_description')
            p_quantity = request.POST.get('p_quantity')

            # Fetching the production, raw material, unit, and product based on their respective IDs
            production_id = request.POST.get('production')
            rm_id = request.POST.get('rm')
            uid = request.POST.get('uid')
            product_id = request.POST.get('p')

            # Fetching related objects using their respective IDs
            production = Production.objects.get(production_id=production_id)
            rawmaterial = RawMaterial.objects.get(rm_id=rm_id)
            units = Unit.objects.get(uid=uid)
            product = Product.objects.get(p_id=product_id)

            # Update the fields in the ProductionRm object
            p.p_rm_description = p_rm_description
            p.p_quantity = p_quantity
            p.production = production
            p.rm = rawmaterial
            p.p = product
            p.uid = units

            p.save()

            return redirect("/productionrmlist/")
        
def productionrmsave(request):
    p_rm_id=request.POST.get('p_rm_id')
    p_rm_description=request.POST.get('p_rm_description')
    p_quantity=request.POST.get('p_quantity')
    production=request.POST.get('production')
    rawmaterial=request.POST.get('rm')
    product=request.POST.get('p')
    uid=request.POST.get('uid')
    units=Unit.objects.get(uid=uid)
    rawmaterial=RawMaterial.objects.get(rm_id=rawmaterial)
    product= Product.objects.get(p_id=product)
    production=Production.objects.get(production_id=production)
    ProductionRm.objects.create(p_rm_id=p_rm_id,p_rm_description=p_rm_description,p_quantity=p_quantity,production=production,rm=rawmaterial,p=product,uid=units)
    return redirect("/productionrmlist/")


#customer login form
def registration(request):
    areas=Area.objects.all()

    return render(request,"login/index.html",{'areas':areas})

def registrationsave(request):
    name = request.POST.get('cust_name')
    dateofbirth = request.POST.get('cust_dob')
    contact = request.POST.get('cust_contact')
    email = request.POST.get('cust_email')
    password = request.POST.get('cust_password')
    address = request.POST.get('cust_address')
    pincode = request.POST.get('pincode')
    areas = Area.objects.get(pincode=pincode)

    imgurl = None
    if 'cust_image' in request.FILES:
        cfile = request.FILES['cust_image']
        fss = FileSystemStorage()
        sfile = fss.save(cfile.name, cfile)
        imgurl = fss.url(sfile)

    Customer.objects.create(
        cust_name=name,
        cust_dob=dateofbirth,
        cust_contact=contact,
        cust_email=email,
        cust_image=imgurl,
        cust_password=password,
        cust_address=address,
        pincode=areas
    )
    return redirect("/login/")
def Login(request):
    return render(request, "login/login.html")

def checklogin(request):
    if request.method == "POST":
        email = request.POST.get("email")
        pwd = request.POST.get("password")  # Changed to match template field name
        cust = Customer.objects.filter(cust_email=email, cust_password=pwd)
        if cust.exists():
            for c in cust:
                request.session["cid"] = c.cust_id
                return redirect("/vproductlist/")
        else:
            return render(request, "login/login.html", {
                "error_message": "Invalid Email or Password"
            })
    return redirect("/login/")
def alogin(request):
    return render(request,"adminlogin.html")

def adminchecklogin(request):
     if request.method == "POST":
        name = request.POST.get("a_name")
        password = request.POST.get("Password")
        
        admin = Admin.objects.filter(a_name=name, a_password=password).first()  # sirf ek admin mile to
        
        if admin:
            request.session["a_id"] = admin.a_id
            messages.success(request, "Login Successfully!")
            return redirect("/adashboard/")
        else:
            messages.error(request, "Invalid Username or Password!")
            return redirect("/alogin/")
def home(request):
    if request.session.has_key("cid")==False:
        link=False
    else:
        link=True
   
    product = Product.objects.all()
    productpackings=ProductPacking.objects.all()
    feedbacks=Feedback.objects.all()

    
    return render(request,"visitor/home.html",{'products':product,'productpackings':productpackings,"feedbacks":feedbacks,"link":link})


def contact(request):
    if request.session.has_key("cid")==False:
        link=False
    else:
        link=True
   
    return render(request,"visitor/contact.html",{"link":link})


def cart(request):
    if request.session.has_key("cid")==False:
        return redirect("/login/")
    if request.session.has_key("cid")==False:
        link=False
    else:
        link=True
   
    cid=request.session.get("cid")
    cust=Customer.objects.get(cust_id=cid)
    carts=AddToCart.objects.filter(cust=cust)
    total=0
    
    for c in carts:
        total=int(total)+int(c.total)
    return render(request,"visitor/cart.html",{"carts":carts,"total":total,"link":link})

def checkout(request):
    if request.session.has_key("cid")==False:
        return redirect("/login/")
    if request.session.has_key("cid")==False:
        link=False
    else:
        link=True
   
    cid=request.session.get("cid")
    cust=Customer.objects.get(cust_id=cid)
    carts=AddToCart.objects.filter(cust=cust)
    total=0
    
    for c in carts:
        total=int(total)+int(c.total)
    dt=date.today()
    sell=Sell.objects.create(cust=cust,sell_date=dt,total=total,status="Pending")
    for c in carts:
        SellDetail.objects.create(sell=sell,quantity=c.quantity,rate=c.rate,pack=c.pack)
    for c in carts:
        c.delete()
    return redirect("/myorder/",{"link":link})

def addcart(request):
    if request.session.has_key("cid")==False:
        return redirect("/login/")
    if request.session.has_key("cid")==False:
        link=False
    else:
        link=True
   
    cid=request.session.get("cid")
    cust=Customer.objects.get(cust_id=cid)
    packid=request.POST.get('packid')
    pprice=request.POST.get('price')
    pack=ProductPacking.objects.get(pack_id=packid) 
    qty=request.POST.get('qty')
    tot=int(pprice)*int(qty)
    AddToCart.objects.create(cust=cust,pack=pack,quantity=qty,rate=pprice,total=tot)

    return redirect("/cart/",{"link":link})

def cartdel(request,id):
    a = AddToCart.objects.get(cart_id= id)
    a.delete()
    return redirect("/cart/")

def myorder(request):
    if request.session.has_key("cid")==False:
        return redirect("/login/")
    if request.session.has_key("cid")==False:
        link=False
    else:
        link=True
   
    cid=request.session.get("cid")
    cust=Customer.objects.get(cust_id=cid)
    sells=Sell.objects.filter(cust=cust)
    selldetails = SellDetail.objects.all()

    return render(request,"visitor/myorder.html",{"sells":sells,"selldetails":selldetails,"link":link})

def productionjoin(request):
    production=Production.objects.all()
    productionrm=ProductionRm.objects.all()
    productionproduct=ProductionProduct.objects.all()
    
    return render(request,"productionjoin.html",{"productions":production,"productionrms":productionrm,'productionproducts':productionproduct})




    
    
def Bill(request,id):
    sell=Sell.objects.get(sell_id=id)
    selldetails = SellDetail.objects.filter(sell=sell)
    
    for s in selldetails:
            price=int(s.quantity)*int(s.rate)
    return render(request,"bill.html",{'sell':sell,"selldetails":selldetails,"price":price})

def viewprofile(request):
    if not request.session.has_key("cid"):  # session check for customer
        return redirect("/login/")
    
    cust_id = request.session.get("cid")  # get customer id from session
    try:
        cust = Customer.objects.get(cust_id=cust_id)  # fetch customer details
    except Customer.DoesNotExist:
        return redirect("/login/")  # redirect if no customer found
    
    areas = Area.objects.all()  # fetch all areas

    return render(request, "visitor/viewprofile.html", {'cust': cust, 'areas': areas})
def profileupdate(request):
    if not request.session.has_key("cid"):  # Check if user is logged in
        return redirect("/login/")

    cust_id = request.session.get("cid")
    c = Customer.objects.get(cust_id=cust_id)

    # Retrieve form data
    name = request.POST.get('cust_name')
    dateofbirth = request.POST.get('cust_dob')
    contact = request.POST.get('cust_contact')
    email = request.POST.get('cust_email')
    password = request.POST.get('cust_password')
    address = request.POST.get('cust_address')
    pincode = request.POST.get('pincode')

    # Update fields
    c.cust_name = name
    c.cust_dob = dateofbirth
    c.cust_contact = contact
    c.cust_email = email
    c.cust_password = password
    c.cust_address = address

    # Handle image update safely
    try:
        cfile = request.FILES["cust_image"]
        fss = FileSystemStorage()
        sfile = fss.save(cfile.name, cfile)
        imgurl = fss.url(sfile)
        c.cust_image = imgurl  # Update only if a new image is uploaded
    except MultiValueDictKeyError:
        pass  # Keep the existing image if no new one is uploaded

    # Handle Area (if pincode exists)
    try:
        areas = Area.objects.get(pincode=pincode)
        c.pincode = areas
    except Area.DoesNotExist:
        pass  # Handle the case where the pincode is not found

    c.save()
    return redirect("/home/")
def aboutus(request):
    if request.session.has_key("cid")==False:
        link=False
    else:
        link=True
    
    return render(request,"visitor/aboutus.html",{"link":link})

def feedback(request):
    if request.session.has_key("a_id")==False:
        return redirect("/alogin/")
    
    feedbacks=Feedback.objects.all()
    return render(request,"feedback.html",{'feedbacks':feedbacks})

def feedbackadd(request):
    if request.session.has_key("cid")==False:
        return redirect("/login/")
    cid=request.session.get("cid")
    cust=Customer.objects.get(cust_id=cid)
    
    feed_desc=request.POST.get('feed_desc')
    Feedback.objects.create(feed_desc=feed_desc,cust=cust)
    return redirect("/home/")


