from django.db import models

# Create your models here.

class Admin(models.Model):
    a_id = models.AutoField(primary_key=True)
    a_name = models.CharField(max_length=30)
    a_password = models.CharField(max_length=8)

    class Meta:
        managed = False
        db_table = 'admin'


class Area(models.Model):
    pincode = models.IntegerField(primary_key=True)
    area_name = models.CharField(max_length=50)
    c = models.ForeignKey('City', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'area'



class Category(models.Model):
    cid = models.AutoField(primary_key=True)
    cname = models.CharField(max_length=30)
    cimg = models.CharField(max_length=300)

    class Meta:
        managed = False
        db_table = 'category'


class City(models.Model):
    c_id = models.AutoField(primary_key=True)
    c_name = models.CharField(max_length=50)
    sid = models.ForeignKey('State', models.DO_NOTHING, db_column='sid')

    class Meta:
        managed = False
        db_table = 'city'


class Customer(models.Model):
    cust_id = models.AutoField(primary_key=True)
    cust_name = models.CharField(max_length=60)
    cust_dob = models.DateField(blank=True, null=True)
    cust_contact = models.BigIntegerField()
    cust_email = models.CharField(max_length=50)
    cust_image = models.CharField(max_length=200, blank=True, null=True)
    cust_password = models.CharField(max_length=50)
    cust_address = models.CharField(max_length=100, blank=True, null=True)
    pincode = models.ForeignKey(Area, models.DO_NOTHING, db_column='pincode', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'customer'



class Employee(models.Model):
    emp_id = models.AutoField(primary_key=True)
    emp_name = models.CharField(max_length=60)
    emp_email = models.CharField(max_length=50)
    emp_contact = models.FloatField()
    emp_password = models.CharField(max_length=50)
    emp_image = models.CharField(max_length=100, blank=True, null=True)
    emp_address = models.CharField(max_length=100)
    emp_d0b = models.DateField(db_column='emp_D0B', blank=True, null=True)  # Field name made lowercase.
    emp_doj = models.DateField()
    pincode = models.ForeignKey(Area, models.DO_NOTHING, db_column='pincode')

    class Meta:
        managed = False
        db_table = 'employee'


class Product(models.Model):
    p_id = models.AutoField(primary_key=True)
    p_name = models.CharField(max_length=60)
    p_image = models.CharField(max_length=200)
    p_description = models.CharField(db_column='p_Description', max_length=300)  # Field name made lowercase.
    subcat = models.ForeignKey('ProductSubcategory', models.DO_NOTHING, blank=True, null=True)
    p_price = models.IntegerField()
    p_shelf_life = models.IntegerField(db_column='P_shelf_life')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'product'


class ProductPacking(models.Model):
    pack_id = models.AutoField(primary_key=True)
    p = models.ForeignKey(Product, models.DO_NOTHING)
    pack_price = models.IntegerField()
    pack_image = models.CharField(max_length=300)
    uid = models.ForeignKey('Unit', models.DO_NOTHING, db_column='uid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'product_packing'


class ProductSubcategory(models.Model):
    subcat_id = models.AutoField(primary_key=True)
    sub_name = models.CharField(max_length=50)
    sub_image = models.CharField(max_length=200)
    cat = models.ForeignKey(Category, models.DO_NOTHING, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'product_subcategory'


class Production(models.Model):
    production_id = models.AutoField(primary_key=True)
    batch_no = models.CharField(max_length=50)
    production_date = models.DateField()
    emp = models.ForeignKey(Employee, models.DO_NOTHING)
    description = models.CharField(max_length=300)
    status = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'production'


class ProductionProduct(models.Model):
    production = models.ForeignKey(Production, models.DO_NOTHING)
    production_p_id = models.AutoField(primary_key=True)
    quantity = models.IntegerField(db_column='Quantity')  # Field name made lowercase.
    pack = models.ForeignKey(ProductPacking, models.DO_NOTHING, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'production_product'


class ProductionRm(models.Model):
    p_rm_id = models.AutoField(primary_key=True)
    p_rm_description = models.CharField(max_length=300)
    p_quantity = models.IntegerField()
    production = models.ForeignKey(Production, models.DO_NOTHING)
    rm = models.ForeignKey('RawMaterial', models.DO_NOTHING, blank=True, null=True)
    uid = models.ForeignKey('Unit', models.DO_NOTHING, db_column='uid', blank=True, null=True)
    p = models.ForeignKey(Product, models.DO_NOTHING, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'production_rm'


class ProductionStock(models.Model):
    p_stock_id = models.AutoField(db_column='P_stock_id', primary_key=True)  # Field name made lowercase.
    production_p = models.ForeignKey(ProductionProduct, models.DO_NOTHING, blank=True, null=True)
    qunatity = models.IntegerField()
    stock_date = models.DateField()
    production = models.ForeignKey(Production, models.DO_NOTHING, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'production_stock'


class Purchase(models.Model):
    purchase_id = models.AutoField(primary_key=True)
    purchase_date = models.DateField()
    sup = models.ForeignKey('Supplier', models.DO_NOTHING)
    status = models.CharField(max_length=50)
    total = models.IntegerField(db_column='Total')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'purchase'


class PurchaseDesc(models.Model):
    purchase_d_id = models.AutoField(primary_key=True)
    purchase = models.ForeignKey(Purchase, models.DO_NOTHING)
    quantity = models.IntegerField()
    rate = models.IntegerField()
    rm = models.ForeignKey('RawMaterial', models.DO_NOTHING, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'purchase_desc'


class RawMaterial(models.Model):
    rm_id = models.AutoField(primary_key=True)
    rm_descripition = models.CharField(max_length=300)
    uid = models.ForeignKey('Unit', models.DO_NOTHING, db_column='uid')
    rm_name = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'raw_material'


class RmStock(models.Model):
    rm_stock_id = models.AutoField(primary_key=True)
    rm = models.ForeignKey(RawMaterial, models.DO_NOTHING, blank=True, null=True)
    stock_date = models.DateField()
    quantity = models.IntegerField()
    uid = models.ForeignKey('Unit', models.DO_NOTHING, db_column='uid', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'rm_stock'


class Sell(models.Model):
    sell_id = models.AutoField(primary_key=True)
    sell_date = models.DateField()
    total = models.IntegerField(db_column='Total')  # Field name made lowercase.
    cust = models.ForeignKey(Customer, models.DO_NOTHING, blank=True, null=True)
    docket_num = models.IntegerField(blank=True, null=True)
    track_url = models.CharField(max_length=60, blank=True, null=True)
    status = models.CharField(max_length=30)

    class Meta:
        managed = False
        db_table = 'sell'

class SellDetail(models.Model):
    sd_id = models.AutoField(primary_key=True)
    sell = models.ForeignKey(Sell, models.DO_NOTHING)
    quantity = models.IntegerField()
    rate = models.IntegerField()
    pack = models.ForeignKey(ProductPacking, models.DO_NOTHING, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'sell_detail'


class State(models.Model):
    sid = models.AutoField(primary_key=True)
    sname = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'state'


class Supplier(models.Model):
    sup_id = models.AutoField(primary_key=True)
    sup_name = models.CharField(max_length=60)
    sup_contact = models.FloatField()
    sup_address = models.CharField(max_length=100, blank=True, null=True)
    sup_email = models.CharField(max_length=50)
    pincode = models.ForeignKey(Area, models.DO_NOTHING, db_column='pincode', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'supplier'


class Unit(models.Model):
    uid = models.AutoField(primary_key=True)
    uname = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'unit'


class AddToCart(models.Model):
    cart_id = models.AutoField(primary_key=True)
    cust = models.ForeignKey('Customer', models.DO_NOTHING)
    pack = models.ForeignKey('ProductPacking', models.DO_NOTHING)
    quantity = models.IntegerField()
    rate = models.IntegerField()
    total = models.FloatField()

    class Meta:
        managed = False
        db_table = 'add_to_cart'

class Feedback(models.Model):
    feedback_id = models.AutoField(primary_key=True)
    cust = models.ForeignKey(Customer, models.DO_NOTHING)
    feed_desc = models.CharField(max_length=250)

    class Meta:
        managed = False
        db_table = 'feedback'
